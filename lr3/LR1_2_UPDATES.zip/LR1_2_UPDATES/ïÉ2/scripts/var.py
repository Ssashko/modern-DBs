class Variables:
    count_product = 500
    count_country = 8
    count_city = 10
    count_street = 200
    count_address = 500
    count_vendor = 0
    count_ingridient = 9
    count_typeOfProduct = 6
    count_typeOfPurchase = 5
    count_licence = 2
    count_producer = 6
    count_supply = 1000
    count_cashier = 15
    count_check = 4000
    count_checkItem = 16000
    count_medicalExamination = 50
    count_schedule = 500